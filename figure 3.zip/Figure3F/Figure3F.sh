cnkit.py heatmap 'cat filenames.txt'
